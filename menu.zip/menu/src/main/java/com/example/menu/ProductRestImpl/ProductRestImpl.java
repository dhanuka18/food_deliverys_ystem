package com.example.menu.ProductRestImpl;

import ch.qos.logback.core.model.Model;
import com.example.menu.ProductRepository.ProductRepository;
import com.example.menu.ProductRest.ProductRest;
import com.example.menu.ProductService.ProductService;
import com.example.menu.RestaurantConstants.RestaurantConstants;
import com.example.menu.RestaurantConstants.RestaurantUtils;
import com.example.menu.entity.Product;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/mymenu")
public class ProductRestImpl implements ProductRest {
    @Autowired
    ProductService productservice;
    @Autowired
    ProductRepository productrepository;


    @GetMapping
    public String getMenuPage() {
        return "menu";
    }
    @GetMapping("/list")
    public String getMenuList(Model model) {
        List<Product> productList = productservice.getAllMenuItems();
        model.addText("products");
        System.out.println("Product List Size: " + productList.size());
        return "menu";
    }

    @GetMapping("/getProductNames")
    @ResponseBody
    public List<String> getProductNames() {
        return productservice.getAllProductNames();
    }


    @PostMapping("/addNewProduct")
    public String addMenuItem(@RequestParam Map<String, String> requestMap, Model model) {
        ResponseEntity<String> responseEntity = productservice.addNewProduct(requestMap);
        model.addText("message");
        List<Product> productList = productservice.getAllMenuItems();
        model.addText("products");
        return "menu";
    }
    @PostMapping("/update")

    public String updateMenuItemCall(@RequestParam Map<String, String> requestMap, Model model) {

        String productName = requestMap.get("productNameUpdate");
        Product existingProduct = productrepository.findByName(productName);
        if (existingProduct != null) {

            existingProduct.setName(requestMap.get("nameUpdate"));
            existingProduct.setStatus(Integer.parseInt(requestMap.get("statusUpdate")));
            existingProduct.setPrice(Integer.parseInt(requestMap.get("priceUpdate")));
            productrepository.save(existingProduct);
            model.addText("message");
        } else {
            model.addText("message");
        }
        List<Product> productList = productservice.getAllMenuItems();
        model.addText("products");
        return "menu";
    }
    @PostMapping("/delete")
    public String deleteMenuItem(@RequestParam String productNameDelete, Model model) {

        Product existingProduct = productrepository.findByName(productNameDelete);
        if (existingProduct != null) {

            Integer productId = existingProduct.getProductId();
            productrepository.deleteById(productId);
            model.addText("message");
        } else {
            model.addText("message");
        }
        List<Product> productList = productservice.getAllMenuItems();
        model.addText("products");
        return "menu";
    }
    @Override
    public ResponseEntity<String> addNewProduct(Map<String, String> requestMap) {
        try {
            return productservice.addNewProduct(requestMap);
        }catch(Exception ex) {
            ex.printStackTrace();
        }

        return RestaurantUtils.getResponseEntity(RestaurantConstants.Something_Went_WRONG, HttpStatus.INTERNAL_SERVER_ERROR);


    }
    @Override
    public ResponseEntity<String> deleteMenuItem(@PathVariable Integer productId) {
        return productservice.deleteMenuItem(productId);
    }
    @Override
    public ResponseEntity<String> updateMenuItem(Map<String, String> requestMap) {
        return productservice.updateMenuItem(requestMap);
    }
}
