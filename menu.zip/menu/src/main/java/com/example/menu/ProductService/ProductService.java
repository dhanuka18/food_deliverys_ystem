package com.example.menu.ProductService;

import com.example.menu.entity.Product;
import org.springframework.http.ResponseEntity;

import java.util.List;
import java.util.Map;

public interface ProductService {
    List<Product> getAllMenuItems();
    ResponseEntity<String> addNewProduct(Map<String,String> requestMap);

    ResponseEntity<String> updateMenuItem( Map<String, String> requestMap);
    ResponseEntity<String> deleteMenuItem(Integer productId);

    List<String> getAllProductNames();


}

