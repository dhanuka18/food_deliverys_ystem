package com.example.menu.ProductRest;

import org.springframework.http.ResponseEntity;

import java.util.Map;

public interface ProductRest {
    ResponseEntity<String> addNewProduct(Map<String, String> requestMap);
    ResponseEntity<String> updateMenuItem( Map<String, String> requestMap);
    ResponseEntity<String> deleteMenuItem(Integer productId);

}