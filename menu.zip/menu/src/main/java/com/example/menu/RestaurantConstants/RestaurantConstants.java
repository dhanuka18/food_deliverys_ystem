package com.example.menu.RestaurantConstants;

public class RestaurantConstants {
    public static final String Something_Went_WRONG = "Something went Wrong";
    public static final String UNAUTHORIZED_ACCESS = "You are not authorized";
    public static final String Invalid_DATA = "Invalid Data";
}